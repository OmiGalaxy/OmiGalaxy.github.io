import java.util.Scanner;
import java.io.*;

public class file {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the name of the file: ");
        String filename = sc.nextLine();

        File file = new File(filename);

        try {
            if (file.exists()) {
                // File exists: Display contents
                System.out.println("Displaying contents of the file:");
                BufferedReader br = new BufferedReader(new FileReader(file));
                String line;
                while ((line = br.readLine()) != null) {
                    System.out.println(line);
                }
                br.close();

                // Menu options
                System.out.println("1. Append data at the end of the file");
                System.out.println("2. Replace specified text in the file");
                System.out.print("Choose an option (1 or 2): ");
                int option = sc.nextInt();
                sc.nextLine(); // Consume newline

                if (option == 1) {
                    System.out.println("Enter the data to append into file:");
                    String appendData = sc.nextLine();

                    FileWriter fw = new FileWriter(file, true);
                    fw.write(appendData + "\n");
                    fw.close();
                    System.out.println("Data appended successfully.");

                } else if (option == 2) {
                    System.out.println("Enter the data to replace:");
                    String oldData = sc.nextLine();
                    System.out.println("Enter the new data:");
                    String newData = sc.nextLine();

                    // Read and replace content
                    StringBuilder sb = new StringBuilder();
                    BufferedReader reader = new BufferedReader(new FileReader(file));
                    while ((line = reader.readLine()) != null) {
                        sb.append(line.replace(oldData, newData)).append("\n");
                    }
                    reader.close();

                    // Write new content
                    FileWriter writer = new FileWriter(file);
                    writer.write(sb.toString());
                    writer.close();
                    System.out.println("Data replaced successfully.");
                } else {
                    System.out.println("Invalid option.");
                }

            } else {
                // File does not exist: Create and write
                System.out.print("File does not exist. Enter data to store in the new file: ");
                String data = sc.nextLine();

                FileWriter fw = new FileWriter(file);
                fw.write(data + "\n");
                fw.close();
                System.out.println("New file created and data stored.");

                // Display new file content
                System.out.println("Displaying contents of the new file:");
                BufferedReader br = new BufferedReader(new FileReader(file));
                String line;
                while ((line = br.readLine()) != null) {
                    System.out.println(line);
                }
                br.close();
            }
        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }

        sc.close();
    }
}
