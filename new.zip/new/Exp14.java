import java.io.*;
import java.util.*;

public class Exp14 {
    public static void main(String[] args) {
        LinkedList<String> linkedList = new LinkedList<>();
        File file = new File("abc.txt");

        // Read file and add lines to LinkedList
        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                linkedList.add(line);
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + file.getAbsolutePath());
            return;
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
            return;
        }

        // Display original order
        System.out.println("Contents of LinkedList:");
        for (String line : linkedList) {
            System.out.println(line);
        }

        // Display reverse order
        System.out.println("\nContents in Reverse Order:");
        Iterator<String> iterator = linkedList.descendingIterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }
    }
}
