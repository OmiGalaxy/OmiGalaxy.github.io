import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;

public class Exp12_tcpclient extends JFrame implements ActionListener {

    private JButton sendButton, exitButton;
    private static JTextArea messageArea;
    private static JTextField inputField;
    private static Socket socket;

    public Exp12_tcpclient() {
        setTitle("CLIENT");
        setSize(500, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        inputField = new JTextField(15);
        messageArea = new JTextArea();
        messageArea.setEditable(false);
        messageArea.setLineWrap(true);
        messageArea.setWrapStyleWord(true);

        JScrollPane scrollPane = new JScrollPane(messageArea);
        scrollPane.setPreferredSize(new Dimension(300, 100));
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        sendButton = new JButton("SEND");
        exitButton = new JButton("EXIT");

        sendButton.addActionListener(this);
        exitButton.addActionListener(this);

        add(inputField);
        add(scrollPane);
        add(sendButton);
        add(exitButton);
        inputField.requestFocus();
    }

    public void actionPerformed(ActionEvent ae) {
        try {
            String command = ae.getActionCommand();
            if (command.equals("SEND")) {
                String message = inputField.getText();
                messageArea.append("\nMe: " + message);
                PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);
                writer.println(message);
                inputField.setText("");
            } else if (command.equals("EXIT")) {
                System.exit(0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws IOException {
        Exp12_tcpclient client = new Exp12_tcpclient();
        client.setVisible(true);

        socket = new Socket("localhost", 888);
        messageArea.setText("Connected to Server on port 888.");

        BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        String line;

        while ((line = reader.readLine()) != null) {
            messageArea.append("\nServer: " + line);
        }
    }
}

***************************************************************************************************************************************************

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;

public class Exp12_tcpserver extends JFrame implements ActionListener {

    private JButton sendButton, exitButton;
    private static JTextArea messageArea;
    private static JTextField inputField;
    private static Socket socket;

    public Exp12_tcpserver() {
        setTitle("SERVER");
        setSize(500, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        inputField = new JTextField(15);
        messageArea = new JTextArea();
        messageArea.setEditable(false);
        messageArea.setLineWrap(true);
        messageArea.setWrapStyleWord(true);

        JScrollPane scrollPane = new JScrollPane(messageArea);
        scrollPane.setPreferredSize(new Dimension(300, 100));
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        sendButton = new JButton("SEND");
        exitButton = new JButton("EXIT");

        sendButton.addActionListener(this);
        exitButton.addActionListener(this);

        add(inputField);
        add(scrollPane);
        add(sendButton);
        add(exitButton);
        inputField.requestFocus();
    }

    public void actionPerformed(ActionEvent ae) {
        try {
            String command = ae.getActionCommand();
            if (command.equals("SEND")) {
                String message = inputField.getText();
                messageArea.append("\nMe: " + message);
                PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);
                writer.println(message);
                inputField.setText("");
            } else if (command.equals("EXIT")) {
                System.exit(0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws IOException {
        Exp12_tcpserver server = new Exp12_tcpserver();
        server.setVisible(true);

        ServerSocket serverSocket = new ServerSocket(888);
        messageArea.setText("Waiting for client connection...");
        socket = serverSocket.accept();
        messageArea.append("\nClient connected.");

        BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        String line;

        while ((line = reader.readLine()) != null) {
            messageArea.append("\nClient: " + line);
        }
    }
}
