 

class LowBalanceException extends Exception{
	public LowBalanceException(String message){
		super(message);
	}
}

class NegativeNumberException extends Exception{
	public NegativeNumberException(String message){
		super(message);
	}
}

class PasswordMismatchException extends Exception{
	public PasswordMismatchException(String message){
		super(message);
	}
}

class BankAccount{
	double balance;
	String pass;
	public BankAccount(double balance, String pass){
		this.balance = balance;
		this.pass = pass;
	}
	
	public void withdraw(double amount, String EnteredPass) throws LowBalanceException, NegativeNumberException, PasswordMismatchException {
		if(amount>balance){
			throw new LowBalanceException("You have Low Balnce to Withdraw !!");
		}
		if(amount<0){
			throw new NegativeNumberException("Enter Valid Amount to Withdraw !!");
		}
		if(!EnteredPass.equals(pass)){
			throw new PasswordMismatchException("Invalid Password !!");
		}
		balance -= amount;
		System.out.println("Withdraw Successfull : Amount : "+amount+" || Balance : "+balance);
	}
	
	public void deposite(double amount) throws NegativeNumberException{
		if(amount<=0){
			throw new NegativeNumberException("Enter Valid Amount to Deposite !!");
		}
		balance += amount;
		System.out.println("Deposite Successfull : Amount : "+amount+" || Balance : "+balance);
	}
	
	public double balanceEnquery(String EnteredPass) throws PasswordMismatchException{
	 if(!EnteredPass.equals(pass)){
			throw new PasswordMismatchException("Invalid Password !!");
	 }
	 return balance;
	}
	
	public void transfer(BankAccount receiver, double amount, String EnteredPass) throws PasswordMismatchException, NegativeNumberException, LowBalanceException{
	  if(!EnteredPass.equals(pass)){
			throw new PasswordMismatchException("Invalid Password !!");
	  }
	  if(amount<0){
			throw new NegativeNumberException("Enter Valid Amount to Transfer !!");
	  }
	  if(amount>balance){
			throw new LowBalanceException("You have Low Balnce to Withdraw !!");
	  }
	  
	  receiver.balance += amount;
	  this.balance -= amount;
	  System.out.println("Transfer Successfull : Amount : "+amount);
	  System.out.println("User2 Balance : "+receiver.balance);
	  System.out.println("User1 Balance : "+balance);
	}
	
}

class BankAccountTest7{
 public static void main(String args[]){
   try{
	   
	   BankAccount b1 = new BankAccount(1000,"abc123");
	   BankAccount b2 = new BankAccount(500,"xyz123");
	   
	   System.out.println("\nUser 1 : ");
	   System.out.println("Balance : "+ b1.balanceEnquery("abc123"));
	   b1.withdraw(200,"abc123");
	   b1.deposite(400);
	   
	   System.out.println("\nUser 2 : ");
	   System.out.println("Balance : "+ b2.balanceEnquery("xyz123"));
	   b2.deposite(400);
	   b2.withdraw(200,"xyz123");
	   
	   System.out.println("\nTransfer From User1 -> User 2 : ");
	   b1.transfer(b2,500,"abc123");
   }
   catch(Exception e){
	   System.out.println("\nException : "+e.getMessage());
   }
 }
}