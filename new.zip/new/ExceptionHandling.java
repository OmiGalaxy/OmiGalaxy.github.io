 
import java.util.InputMismatchException;
import java.util.Scanner;
public class ExceptionHandling {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);

        try{
            //  1] ArithmeticException (Divide by zero)
            System.out.println("\n 1]ArithmeticException : Divide By Zero\n");
            System.out.print("Enter First Number : ");
            int num1 = sc.nextInt();
            System.out.print("Enter Second Number : ");
            int num2 = sc.nextInt();
            float div = num1/num2;
            System.out.println("Division : "+div);

            // 2] ArrayIndexOutOfBoundsException
            System.out.println("\n2] ArrayIndexOutOfBoundsException \n");
            int arr[] = {1,2,3};
            System.out.println("Accesing index 7 in arr size of 3 : "+arr[1]);

            // 3] NullPointerException
            String str = null;
            System.out.println("String Length : "+ str.length());

            // 4] NumberFormatException 
            System.out.print("Enter a Number String : ");
            String ip = sc.next();
            int num = Integer.parseInt(ip);
            System.out.println("Number in Integer : "+num);

            // 5] InputMismatchException
            System.out.print("Enter an integer : ");
            int value = sc.nextInt();
            System.out.println("Integer : "+value);
        } 
        catch(ArithmeticException e){
            System.out.println("\nMessaage : Can not divide by zero !!");
            System.out.println("Exception : "+ e);
        }
        catch(ArrayIndexOutOfBoundsException e){
            System.out.println("\nMessaage : Can not access index outside the size of array !!");
            System.out.println("Exception : "+ e);
        }
        catch(NullPointerException e){
            System.out.println("\nMessaage : String can not be null for its length !!");
            System.out.println("Exception : "+ e);
        }
        catch(NumberFormatException e){
            System.out.println("\nMessaage : Enter the valid Number String !!");
            System.out.println("Exception : "+ e);
        }
        catch(InputMismatchException e){
            System.out.println("\nMessaage : Enter the valid Integer !!");
            System.out.println("Exception : "+ e);
        }

        finally{
            System.out.println("\nFinally Block Executed !! \n");
        }
    }
}
