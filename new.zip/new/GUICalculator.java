import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class GUICalculator extends JFrame implements ActionListener {
    JTextField textField;
    double num1, num2, result;
    char operator;

    public GUICalculator() {
        // Set basic frame properties
        setTitle("Simple Calculator");
        setSize(250, 300);
        setLayout(new BorderLayout());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create input field at top
        textField = new JTextField();
        add(textField, BorderLayout.NORTH);

        // Create panel with 4x4 grid layout for buttons
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 4));

        // Define calculator buttons
        String[] buttons = {
            "7", "8", "9", "+",
            "4", "5", "6", "-",
            "1", "2", "3", "*",
            "0", "C", "=", "/"
        };

        // Add buttons to panel and register ActionListener
        for (String b : buttons) {
            JButton button = new JButton(b);
            button.addActionListener(this);
            panel.add(button);
        }

        // Add panel to frame
        add(panel);
        setVisible(true); // Make frame visible
    }

    public void actionPerformed(ActionEvent e) {
        String input = e.getActionCommand();

        // If number pressed
        if (input.charAt(0) >= '0' && input.charAt(0) <= '9') {
            textField.setText(textField.getText() + input);
        }
        // If Clear button pressed
        else if (input.equals("C")) {
            textField.setText("");
        }
        // If Equal (=) button pressed
        else if (input.equals("=")) {
            num2 = Double.parseDouble(textField.getText());

            // Perform operation based on stored operator
            switch (operator) {
                case '+': result = num1 + num2; break;
                case '-': result = num1 - num2; break;
                case '*': result = num1 * num2; break;
                case '/': result = (num2 != 0) ? num1 / num2 : 0; break;
            }

            textField.setText(String.valueOf(result));
        }
        // If operator pressed (+, -, *, /)
        else {
            num1 = Double.parseDouble(textField.getText());
            operator = input.charAt(0); // Store operator
            textField.setText("");      // Clear for next number
        }
    }

    public static void main(String[] args) {
        new GUICalculator(); // Create GUI
    }
}
