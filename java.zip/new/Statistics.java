import java.util.Arrays;

public class Statistics {
    public static double mean(double data[]) {
        int len = data.length;
        double sum = 0;
        for (double ele : data) {
            sum += ele;
        }
        return sum / len;
    }

    public static double median(double data[]) {
        Arrays.sort(data);
        int len = data.length;
        if (len % 2 == 0) {
            return (data[len / 2] + data[len/2 - 1]) / 2.0;
        }
        return data[len / 2];
    }

    public static double standardDeviation(double data[]) {
        double mean = mean(data);

        double sum = 0;
        for (double ele : data) {
            sum += Math.pow(ele - mean , 2);
        }
        return Math.sqrt(sum / data.length);
    }
}

class Converter {
    public static String toBinary(int decimal) {
        return Integer.toBinaryString(decimal);
    }

    public static String toOctal(int decimal) {
        return Integer.toOctalString(decimal);
    }
    public static String toHex(int decimal) {
        return Integer.toHexString(decimal);
    }
}

class StatisticsTest {
    public static void main(String[] args) {
        double data[] = {10,20,30,40,50};
        System.out.println("Mean is : " + Statistics.mean(data));
        System.out.println("Median is : " + Statistics.median(data));
        System.out.println("StandardDeviation is : " + Statistics.standardDeviation(data));
        int number = 100;
        System.out.println("Decimal to Binary = " + Converter.toBinary(number));
    }
}
