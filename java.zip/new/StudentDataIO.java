import java.io.*;
import java.util.Scanner;

// Step 1: Define the Student class
class Student implements Serializable {
    String name;
    int age;
    double weight;
    double height;
    String city;
    String phone;

    public Student(String name, int age, double weight, double height, String city, String phone) {
        this.name = name;
        this.age = age;
        this.weight = weight;
        this.height = height;
        this.city = city;
        this.phone = phone;
    }
}

public class StudentDataIO {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String fileName = "studentdata.dat";

        try {
            // Step 2: Take input from user
            System.out.print("Enter Name: ");
            String name = scanner.nextLine();

            System.out.print("Enter Age: ");
            int age = scanner.nextInt();

            System.out.print("Enter Weight: ");
            double weight = scanner.nextDouble();

            System.out.print("Enter Height: ");
            double height = scanner.nextDouble();
            scanner.nextLine(); // consume newline

            System.out.print("Enter City: ");
            String city = scanner.nextLine();

            System.out.print("Enter Phone: ");
            String phone = scanner.nextLine();

            // Step 3: Create student object
            Student student = new Student(name, age, weight, height, city, phone);

            // Step 4: Write to file using DataOutputStream
            FileOutputStream fos = new FileOutputStream(fileName);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(student);
            oos.close();
            fos.close();
            System.out.println("\nStudent data written to file successfully.");

            // Step 5: Read from file using DataInputStream
            FileInputStream fis = new FileInputStream(fileName);
            ObjectInputStream ois = new ObjectInputStream(fis);
            Student readStudent = (Student) ois.readObject();
            ois.close();
            fis.close();

            // Step 6: Display the data
            System.out.println("\n--- Retrieved Student Data ---");
            System.out.println("Name   : " + readStudent.name);
            System.out.println("Age    : " + readStudent.age);
            System.out.println("Weight : " + readStudent.weight);
            System.out.println("Height : " + readStudent.height);
            System.out.println("City   : " + readStudent.city);
            System.out.println("Phone  : " + readStudent.phone);

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        scanner.close();
    }
}
