// Name : Utkarsh Prakash Sisal
// Roll No : 251
// Batch : C3
// Experiment No : 2

class SavingAccount{

      double saving_Balance;
	  static double annualInterestRate;
	  
	  static void modifyInterestRate(double newRate){
	   annualInterestRate = newRate;   
	 }
    
      public void setSavingAccount(double bal){
	    saving_Balance = bal;
	  }	  

      public double calculateMonthlyInterest(){
	    double monthlyRate = saving_Balance*annualInterestRate/12;
		return monthlyRate;
	  }  
	  
	  public double getMonthlySavings(){
		  return (saving_Balance + saving_Balance*annualInterestRate/12);
	  } 
}

class SavingAccountTest{
  
  public static void main(String[] args){
    SavingAccount saver1 = new SavingAccount();
	SavingAccount saver2 = new SavingAccount();
	
	saver1.setSavingAccount(2000);
	SavingAccount.modifyInterestRate(0.04);
	
	System.out.print("\nSAVER 1 : Annual Interest Rate : 4%");
	System.out.println("\nMonthly Interest : "+ saver1.calculateMonthlyInterest());
	System.out.println("New Balance : "+ saver1.getMonthlySavings());
	
	saver2.setSavingAccount(3000);
	System.out.print("\nSAVER 2 : Annual Interest Rate : 4%");
	System.out.println("\nMonthly Interest : "+ saver2.calculateMonthlyInterest());
	System.out.println("New Balance : "+ saver2.getMonthlySavings());
	
	SavingAccount.modifyInterestRate(0.05);
	
	System.out.print("\nSAVER 1 : Annual Interest Rate : 5%");
	System.out.println("\nMonthly Interest : "+ saver1.calculateMonthlyInterest());
	System.out.println("New Balance : "+ saver1.getMonthlySavings());
	
	System.out.print("\nSAVER 2 : Annual Interest Rate : 5%");
	System.out.println("\nMonthly Interest : "+ saver2.calculateMonthlyInterest());
	System.out.println("New Balance : "+ saver2.getMonthlySavings());	
  }
}

