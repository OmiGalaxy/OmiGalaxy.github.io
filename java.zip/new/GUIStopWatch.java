 import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class GUIStopWatch extends JFrame implements ActionListener{
    JLabel timeLabel;
    JButton startButton, stopButton, resetButton, lapButton;
    JTextArea lapArea;
    
    long startTime;
    boolean running = false;
    int lapCount = 1;
    TimerThread timerThread;

    public GUIStopWatch(){
        setTitle("My Stopwatch");
        setSize(500,200);
        setLayout(new BorderLayout());
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        timeLabel = new JLabel("00:00:00", SwingConstants.CENTER);
        add(timeLabel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(1,4));

        startButton = new JButton("Start");
        stopButton = new JButton("Stop");
        resetButton = new JButton("Reset");
        lapButton = new JButton("Lap");

        startButton.addActionListener(this);
        stopButton.addActionListener(this);
        resetButton.addActionListener(this);
        lapButton.addActionListener(this);

        buttonPanel.add(startButton);
        buttonPanel.add(stopButton);
        buttonPanel.add(resetButton);
        buttonPanel.add(lapButton);

        add(buttonPanel, BorderLayout.CENTER);

        lapArea = new JTextArea();
        lapArea.setEditable(false);
        add(new JScrollPane(lapArea), BorderLayout.SOUTH );

        setVisible(true);

    }

    public void actionPerformed(ActionEvent e){
        if(e.getSource() == startButton && !running){
            running = true;
            startTime = System.currentTimeMillis();
            timerThread = new TimerThread();
            timerThread.start();
        }
        else if(e.getSource() == stopButton){
            running = false;
        }
        else if(e.getSource() == resetButton){
            running = false;
            timeLabel.setText("00:00:00");
            lapArea.setText("");
        }
        else if(e.getSource() == lapButton && running){
            lapArea.append("lap : "+ (lapCount++) + " : " + timeLabel.getText()+"\n");
        }
    }

    class TimerThread extends Thread{
      public void run(){
        while(running){
            long elapsed = System.currentTimeMillis() - startTime;

            int seconds = (int) (elapsed/1000)%60;
            int minutes = (int) (elapsed/(1000*60))%60;
            int hours = (int) (elapsed/(1000*60*60));

            String time = String.format("%02d:%02d:%02d",hours,minutes,seconds);

            timeLabel.setText(time);

            try{
                Thread.sleep(500);
            }
            catch(InterruptedException e){
                e.printStackTrace();
            }

        }
      }
    }

    public static void main(String args[]){
        new GUIStopWatch();
    }
}