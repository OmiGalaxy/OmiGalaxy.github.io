// Name : Utkarsh Prakash Sisal
// Roll No : 251
// Batch : C3
// Experiment No : 1

class Employee{
    String fname;
	String lname;
	float m_salary;
	
	public Employee(String fname, String lname, float m_salary){
	 this.fname = fname;
	 this.lname = lname;
	 this.m_salary = m_salary;
	}
	
	public void set(String fname, String lname, Float m_salary){
	 this.fname = fname;
	 this.lname = lname;
	 if(m_salary <0){
		this.m_salary = 0.0f; 
	 }
	 else{
	 this.m_salary = m_salary;
	 }
	}
	
	public String get1(){
	  return fname;	 
	}
	public String get2(){
      return lname;
	}
	public float get3(){
		return m_salary;
	}
	public float get4(){
		return (12*m_salary);
	}
	
	public float getRaised(){
		float raise = (12*m_salary)*0.1f;
		float salary = (m_salary*12)+raise;
		return salary;
	}		
}

class EmployeeTest{
  public static void main(String args[]){

   System.out.println("\nEmployee No : 1");
   Employee obj1 = new Employee("abc","xyz",0.0f);
   obj1.set("Sushant","Sawant",10000.00f);
   System.out.println("First Name : "+obj1.get1());	
   System.out.println("Last Name : "+obj1.get2());
   System.out.println("Monthly Salary: "+obj1.get3());
   System.out.println("Yearly Salary : "+obj1.get4());
   System.out.print("Raised Salary : "+obj1.getRaised());
   
   System.out.println("\n\nEmployee No : 2");
   Employee obj2 = new Employee("abc","xyz",0.0f);
   obj2.set("Atharv","Satape",-10000.00f);
   System.out.println("First Name : "+obj2.get1());	
   System.out.println("Last Name : "+obj2.get2());
   System.out.println("Monthly Salary: "+obj2.get3());
   System.out.println("Yearly Salary : "+obj2.get4());
   System.out.print("Raised Salary : "+obj2.getRaised());
  }
}