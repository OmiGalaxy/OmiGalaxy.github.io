 

import java.util.Scanner;

//interface Stack :

interface Stack{
    int size = 4;
    void push(String str);
    void pop();
    void display();
    void underFlow();
    void overFlow();
}

// 1] String Stack :

class StringStack implements Stack{
    String arr[] = new String[size];
    int top = -1;

    public void push(String str){
        if(top >= size-1){
            overFlow();
        }
        else{
            top++;
            arr[top] = str;
            System.out.println("\n#Push : "+str+" is pushed.");
        }
    }

    public  void pop(){
        if(top<0){
            underFlow();
        }
        else{
            System.out.println("\n#Pop : "+arr[top]+" is poped.");
            top--;
        }
    }

    public void display(){
        System.out.print("\n#Stack : ");
        if(top<0){
            System.out.println("Empty\n");
        }
        else{
        for(int i=0; i<=top; i++){
            System.out.print(arr[i]+" ");
        }
        System.out.println("\n");
      }
    }

    public void underFlow(){
        if(top<0){
            System.out.println("\n#UnderFlow : Stack is Underflow");
        }
        else{
            System.out.println("\n#UnderFlow : Stack Not is Underflow");

        }
    }

    public void overFlow(){
        if(top >= size-1){
            System.out.println("\n#OverFlow : Stack is Overflow");
        }
        else{
        System.out.println("\n#OverFlow : Stack Not is Overflow");
        }
    }
}

 
// 2] Integer Stack :

class IntegerStack implements Stack{
    int arr[] = new int[size];
    int top = -1;

    public void push(String str){
        int num = Integer.parseInt(str);     // Type Casting
        if(top >= size-1){
            overFlow();
        }
        else{
            top++;
            arr[top] = num;
            System.out.println("\n#Push : "+num+" is pushed.");
        }
    }

    public  void pop(){
        if(top<0){
            underFlow();
        }
        else{
            System.out.println("\n#Pop : "+arr[top]+" is poped.");
            top--;
        }
    }

    public void display(){
        System.out.print("\n#Stack : ");
        if(top<0){
            System.out.println("Empty\n");
        }
        else{
        for(int i=0; i<=top; i++){
            System.out.print(arr[i]+" ");
        }
        System.out.println("\n");
      }
    }

    public void underFlow(){
        if(top<0){
            System.out.println("\n#UnderFlow : Stack is Underflow");
        }
        else{
            System.out.println("\n#UnderFlow : Stack Not is Underflow");

        }
    }

    public void overFlow(){
        if(top >= size-1){
            System.out.println("\n#OverFlow : Stack is Overflow");
        }
        else{
        System.out.println("\n#OverFlow : Stack Not is Overflow");
        }
    }
}

// 3] Double Stack :

class DoubleStack implements Stack{
    double arr[] = new double[size];
    int top = -1;

    public void push(String str){
        double num = Double.parseDouble(str);     // Type Casting
        if(top >= size-1){
            overFlow();
        }
        else{
            top++;
            arr[top] = num;
            System.out.println("\n#Push : "+num+" is pushed.");
        }
    }

    public  void pop(){
        if(top<0){
            underFlow();
        }
        else{
            System.out.println("\n#Pop : "+arr[top]+" is poped.");
            top--;
        }
    }

    public void display(){
        System.out.print("\n#Stack : ");
        if(top<0){
            System.out.println("Empty\n");
        }
        else{
        for(int i=0; i<=top; i++){
            System.out.print(arr[i]+" ");
        }
        System.out.println("\n");
      }
    }

    public void underFlow(){
        if(top<0){
            System.out.println("\n#UnderFlow : Stack is Underflow");
        }
        else{
            System.out.println("\n#UnderFlow : Stack Not is Underflow");

        }
    }

    public void overFlow(){
        if(top >= size-1){
            System.out.println("\n#OverFlow : Stack is Overflow");
        }
        else{
        System.out.println("\n#OverFlow : Stack Not is Overflow");
        }
    }
}


// Test Class :

public class StackTest{
    public static void main(String args[]){

        Scanner sc = new Scanner(System.in);
        System.out.println("\nWelcome to Stack Operations System !!");
        System.out.print("\nSelect Stack Type : \n1]String Stack\n2]Integer Stack\n3]Double Stack\n#Enter Choice No : ");
        int t = sc.nextInt();
        int n;
        switch(t){
            case 1 :    System.out.println("\n 1] String Stack : ");
                        StringStack obj1 = new StringStack();
                        while(true){
                          System.out.print("\nEnter the choice :\n1]Push\n2]Pop\n3]Display\n4]Overflow\n5]Underflow\n6]exit\n#Choice : ");
                          n = sc.nextInt();
                          switch(n){
                            case 1 : System.out.print("Enter the String : ");
                                     String val = sc.next();
                                     obj1.push(val);
                                     break;
                            case 2 : obj1.pop();
                                     break;
                            case 3 : obj1.display();
                                     break;
                            case 4 : obj1.overFlow();
                                     break;
                            case 5 : obj1.underFlow();
                                     break;
                            case 6 : System.out.println("\nExit Successfully !!");
                                     break;
                            default : System.out.println("\nInvalid Option !! Enter the number betweem 1 to 6");
                          }
                            
                                if(n==6){
                                    break;
                                }
                                }
            
                     System.out.println("\n------------------------------------------------------------");
                     break;


            case 2 : System.out.println("\n 2] Integer Stack : ");
                     IntegerStack obj2 = new IntegerStack();
                     while(true){
                       System.out.print("\nEnter the choice :\n1]Push\n2]Pop\n3]Display\n4]Overflow\n5]Underflow\n6]exit\n#Choice : ");
                       n = sc.nextInt();
                       switch(n){
                         case 1 : System.out.print("Enter the Integer Number : ");
                                  String val = sc.next();
                                  obj2.push(val);
                                  break;
                         case 2 : obj2.pop();
                                  break;
                         case 3 : obj2.display();
                                  break;
                         case 4 : obj2.overFlow();
                                  break;
                         case 5 : obj2.underFlow();
                                  break;
                         case 6 : System.out.println("\nExit Successfully !!");
                                  break;
                         default : System.out.println("\nInvalid Option !! Enter the number betweem 1 to 6");
                       }
                         
                             if(n==6){
                                 break;
                             }
                             }
         
                  System.out.println("\n------------------------------------------------------------");
                  break;


        case 3 :  System.out.println("\n 3] Double Stack : ");
                  DoubleStack obj3 = new DoubleStack();
                  while(true){
                    System.out.print("\nEnter the choice :\n1]Push\n2]Pop\n3]Display\n4]Overflow\n5]Underflow\n6]exit\n#Choice : ");
                    n = sc.nextInt();
                    switch(n){
                      case 1 : System.out.print("Enter the Double Number : ");
                               String val = sc.next();
                               obj3.push(val);
                               break;
                      case 2 : obj3.pop();
                               break;
                      case 3 : obj3.display();
                               break;
                      case 4 : obj3.overFlow();
                               break;
                      case 5 : obj3.underFlow();
                               break;
                      case 6 : System.out.println("\nExit Successfully !!");
                               break;
                      default : System.out.println("\nInvalid Option !! Enter the number betweem 1 to 6");
                    }
                      
                          if(n==6){
                              break;
                          }
                          }
      
                   System.out.println("\n------------------------------------------------------------");
                   break;
        }

    }
}

