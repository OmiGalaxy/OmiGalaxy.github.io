import java.util.*;

public class Exp13 {
    public static void main(String[] args) {
        // Create and populate a HashMap
        HashMap<Integer, String> map = new HashMap<>();
        map.put(15, "Fifteen");
        map.put(3, "Three");
        map.put(7, "Seven");
        map.put(1, "One");
        map.put(10, "Ten");

        // Display unordered HashMap entries
        System.out.println("HashMap Entries (unordered):");
        for (Map.Entry<Integer, String> entry : map.entrySet()) {
            System.out.println(entry.getKey() + " => " + entry.getValue());
        }

        // Create TreeMap to sort entries by key
        TreeMap<Integer, String> sorted = new TreeMap<>(map);

        // Transfer sorted entries into LinkedHashMap to preserve order
        LinkedHashMap<Integer, String> linkedMap = new LinkedHashMap<>(sorted);

        // Display sorted LinkedHashMap entries
        System.out.println("\nLinkedHashMap Entries (sorted by key):");
        for (Map.Entry<Integer, String> entry : linkedMap.entrySet()) {
            System.out.println(entry.getKey() + " => " + entry.getValue());
        }
    }
}
