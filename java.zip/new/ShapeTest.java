// Name : Utkarsh Prakash Sisal
// Roll No : 251
// Batch : C3
// Experiment No : 3

abstract class Shape{
   float side;
   float area;
   float perimeter;
   
   abstract void calcArea();
   abstract void calcPeri();
   
   public void display(){
     System.out.println("Area : " + area);
	 System.out.println("Perimeter : " + perimeter);
   }
}

class Triangle extends Shape{
   float base;
   float side1;
   float side2;
   float height;
   
   public Triangle(float height, float base, float side1, float side2){
    this.base = base;
	this.height = height;
	this.side1 = side1;
	this.side2 = side2;
   }
   
   void calcArea(){
     area = 0.5f * base * height;
   }
   
   void calcPeri(){
     perimeter =  base + side1 + side2;
   }
 }
 
 class Rectangle extends Shape{
	 float length;
	 float breadth;
	 
	 public Rectangle(float length, float breadth){
		 this.length = length;
		 this.breadth = breadth;
	 }
	 
	 void calcArea(){
		 area = length * breadth;
	 }
	 
	 void calcPeri(){
		 perimeter = 2*(length+breadth);
	 }
 }
 
 class Square extends Shape{
	 
	 public Square(float side){
		 this.side = side;
	 }
	 
	 void calcArea(){
		 area = side * side;
	 }
	 
	 void calcPeri(){
		 perimeter = 4*(side);
	 }
 }
 
  class Circle extends Shape{
	 float radius;
	 
	 public Circle(float radius){
		 this.radius = radius;
	 }
	 
	 void calcArea(){
		 area = 3.14f * radius * radius;
	 }
	 
	 void calcPeri(){
		 perimeter = 2f*3.14f * radius;
	 }
 }
 
 class Cube extends Shape{
	 
	 public Cube(float side){
		 this.side = side;
	 }
	 
	 void calcArea(){
		 area = 6 * side *side;
	 }
	 
	 void calcPeri(){
		 perimeter = 12 * side;
	 }
 }
 
 class ShapeTest{
   public static void main(String args[]){
	System.out.println("\n1] Triangle : ");
    Shape obj1 = new Triangle(10f,20f, 10f, 10f);
	obj1.calcArea();
	obj1.calcPeri();
	obj1.display();
	
	System.out.println("\n2] Rectangle : ");
	Shape obj2 = new Rectangle(10f,20f);
	obj2.calcArea();
	obj2.calcPeri();
	obj2.display();
	
	System.out.println("\n3] Square : ");
	Shape obj3 = new Square(10f);
	obj3.calcArea();
	obj3.calcPeri();
	obj3.display();
	
	System.out.println("\n4] Circle : ");
	Shape obj4 = new Circle(10f);
	obj4.calcArea();
	obj4.calcPeri();
	obj4.display();
	
	System.out.println("\n5] Cube : ");
	Shape obj5 = new Cube(10f);
	obj5.calcArea();
	obj5.calcPeri();
	obj5.display(); 
   }
 }