#include<lpc214x.h>
unsigned int delay;
int main (void)
{
IO0DIR=(1<<10);  //configure P0.10 AS OUTPUT      
while(1)
{
IO0CLR=(1<<10);	 // clear(0) po.10 to turn LED ON		
for(delay=0;delay<500000;delay++);  //delay 
IO0SET=(1<<10);	 //Set(1)P0.10 to turn LED on 
for(delay=0;delay<500000;delay++);  //delay 
}
}
