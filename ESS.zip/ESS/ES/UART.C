#include<lpc214x.h>
int main(void)
{
PINSEL0=0X00000005;		  
U0LCR=0X83;				   
U0DLL=97;
U0LCR=0X03;
while(1)
  {
   while(!(U0LSR &0X20));
   U0THR='a';
  }
}