#include<lpc214x.h>
unsigned int delay;
int main (void)
{
IO0DIR=(1<<11);  //configure P0.10 AS OUTPUT 
IO0DIR=(1<<12);  
IO0DIR=(1<<13);  
IO0DIR=(1<<14);  
IO0DIR=(1<<15);       
while(1)
{
IO0CLR=(1<<11);	 // clear(0) po.10 to turn LED ON
IO0CLR=(1<<12);  
IO0CLR=(1<<13);  
IO0CLR=(1<<14);  
IO0CLR=(1<<15);  		
for(delay=0;delay<500000;delay++);  //delay 
IO0SET=(1<<11);	 //Set(1)P0.10 to turn LED on
IO0SET=(1<<12);  
IO0SET=(1<<13); 
IO0SET=(1<<14);  
IO0SET=(1<<15);    
for(delay=0;delay<500000;delay++);  //delay 
}
}
