AREA ADDITION, CODE, READONLY
ENTRY
START
 LDR R0, =0x1234E640 ; Load lower 32 bits of first 64-bit number into R0
 LDR R1, =0x43210010 ; Load upper 32 bits of first 64-bit number into R1
 LDR R2, =0x12348900 ; Load lower 32 bits of second 64-bit number into R2
 LDR R3, =0x43212102 ; Load upper 32 bits of second 64-bit number into R3
 ADDS R4, R1, R3 ; Add upper 32 bits (R1 + R3), store in R4, and set flags
 ADC R5, R0, R2 ; Add lower 32 bits (R0 + R2 + carry), store in R5
 NOP ; No operation (used for delay or alignment)
 NOP
 NOP
 END ; Mark the end of the file