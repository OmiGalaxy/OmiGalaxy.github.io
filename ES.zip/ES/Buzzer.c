#include <LPC214x.h>   // Header for LPC214x microcontroller
#include <stdio.h>

#define BUZZ 7         // Define BUZZER pin as P0.7

void Delay(void);      // Function prototype for delay

int main(void)         // main should return int
{
    PINSEL0 &= ~(3 << (BUZZ * 2));   // Configure P0.7 as GPIO (clear bits 14 and 15)
    IODIR0 |= (1 << BUZZ);           // Set P0.7 as output

while(1)
    {
        IOSET0 = 1 <<BUZZ;          // Set P0.7 high - turn buzzer ON
Delay();                     // Wait
        IOCLR0 = 1 <<BUZZ;          // Clear P0.7 - turn buzzer OFF
Delay();                     // Wait
    }

    return 0;                        // Return from main
}

void Delay(void)
{
    unsigned int i, j;
for(i = 0; i< 1000; i++)
for(j = 0; j < 700; j++);
}
