#include<reg51.h>
void SerTX(unsigned char x);
void main(void)
{
TMOD = 0X20;
TH1 = 0XFD;
SCON = 0X50;
TR1 = 1;
while (1)
{
  SerTX('T');
  SerTX('K');
  SerTX('I');
  SerTX('E');
  SerTX('T');
}
}
void SerTX(unsigned char X)
{
  SBUF=X;
  while(TI==0);
  TI=0;
}